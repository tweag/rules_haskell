{-|
Module      : SubLib
Description : Test compilation of cabal sublibrary
-}
module SubLib where
-- |test subLibVal doc
subLibVal = "SubLib"
