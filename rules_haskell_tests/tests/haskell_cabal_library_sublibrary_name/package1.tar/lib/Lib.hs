module Lib where
import SubLib

libval = subLibVal ++ " through Lib"
