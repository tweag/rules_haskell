module Main where
import SubLib

main :: IO ()
main = print subLibVal
